var Setting = {
	url : '../SuZhou/data/goods.json',
	sendData: '{"body": {"name": "tom","password":"111111"},"head": {"tokenId": "20983678","version": "1.0"},"mac": ""}'
};